---
name: Feature Request
about: Suggest an idea for this project
title: "[FEATURE] "
labels: enhancement
assignees: ''

---

## Is your feature request related to a problem?
<!-- Describe the problem -->

## Describe the solution you'd like
<!-- What would you like to see -->

## Describe alternatives you've considered
<!-- Any other options -->

## Additional Context
<!-- Any other context or screenshots -->

## Acceptance Criteria
- [ ] 
- [ ] 
- [ ]

## Priority
<!-- Low / Medium / High -->
