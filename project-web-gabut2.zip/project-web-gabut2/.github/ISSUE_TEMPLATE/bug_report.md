---
name: Bug Report
about: Report a bug to help us improve
title: "[BUG] "
labels: bug
assignees: ''

---

## Description
<!-- Brief description of the bug -->

## Steps to Reproduce
1. 
2. 
3. 

## Expected Behavior
<!-- What should happen -->

## Actual Behavior
<!-- What actually happens -->

## Environment
- Browser: 
- OS: 
- Device: 

## Screenshots
<!-- If applicable, add screenshots showing the issue -->

## Additional Context
<!-- Any other context about the problem -->

## Possible Solution
<!-- Optional: suggest a fix -->
